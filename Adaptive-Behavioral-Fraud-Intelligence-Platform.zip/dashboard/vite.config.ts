import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api': {
        target: 'http://fraud-api:8000',
        changeOrigin: true,
      },
      '/ws': {
        target: 'ws://fraud-api:8000',
        ws: true,
        changeOrigin: true,
      }
    }
  }
})
